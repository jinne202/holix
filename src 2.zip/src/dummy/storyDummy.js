export const dummyDataStory = [
    {
        id : "1",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠1",
        user : "더미유저1"
    },
    {
        id : "2",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠2",
        user : "더미유저2"
    },
    {
        id : "3",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠3",
        user : "더미유저3"
    },
    {
        id : "4",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠4",
        user : "더미유저4"
    },
    {
        id : "5",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠5",
        user : "더미유저5"
    },
    {
        id : "6",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠6",
        user : "더미유저6"
    },
    {
        id : "7",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠7",
        user : "더미유저7"
    },
    {
        id : "8",
        coverImage : "https://placeimg.com/500/500/any",
        title : "더미컨텐츠8",
        user : "더미유저8"
    },
]