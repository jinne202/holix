export const apiHost = "http://localhost:8080";
export const imageHost = "https://holix.s3.ap-northeast-2.amazonaws.com/image/";