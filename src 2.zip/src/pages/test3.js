import React from 'react';
import SortCategory2 from '../components/SortCategory2'
import AppLayout from '../components/layout/AppLayout';

const test3 = () => {
    return (
        <AppLayout>
            <SortCategory2/>
        </AppLayout>
    )
}

export default test3;