import React from 'react';
import AppLayout from "../components/layout/AppLayout";

const createPage = () => {
    return (
        <AppLayout>
            <div>
                createPage
            </div>
        </AppLayout>
    )
}

export default createPage;